<div class="footer">
    <div id="footer-content">
        <p>Copyright &copy; AutoExpress 2021 - 2022 | Rakesh Kumar |</p>
    </div>
</div>