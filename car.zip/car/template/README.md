Only static html component that does not change.
