<div class="header">
    <div><img src="image/icon.svg" class="car-logo" alt="Site logo"/></div>
    <div class="clear-both"></div>
    <div class="menu-header">
        <div id="menu-header-left-section">
            <!-- for development
            <span><a href="index.php"><i class="fa fa-home" aria-hidden="true"></i>&nbsp;Used Vehicles</a></span>
             -->
            <span>
                <a href="http://autoexpress.c1.biz"><i class="fa fa-home" aria-hidden="true"></i>&nbsp;Used Vehicles</a>
            </span>
        </div>
        <div class="clear-both"></div>
    </div>
</div>